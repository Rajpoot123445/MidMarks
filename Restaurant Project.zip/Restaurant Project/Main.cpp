#include <iostream>
using namespace std;
#include <fstream>
#include "Testing.h"
#include "fooditems.h"

void MainLandingPage() {
	system("cls");
	
	cout<<"\n\n\t\t\t*******************************************************************"<<endl;
	cout<<"\t\t\t*******************************************************************"<<endl;
	cout << "\n\n\t\t\t\t\t RESTAURANT MANAGEMENT SYSTEM" << endl;
	cout << "\n\t\t\tDEVELOPED BY:\n";
	cout << "\n\t\t\t\t AHMAD ALI ASGHAR \t\t 21-NTU-CS-1203";
	cout << "\n\t\t\t\t MUHAMMAD AWAIS \t\t 21-NTU-CS-1846";
	cout << "\n\t\t\t\t ABDUR REHMAN \t\t\t 21-NTU-CS-1201";	
	cout<<"\n\n\n\t\t\t*******************************************************************"<<endl;
	cout<<"\t\t\t*******************************************************************"<<endl;

	system("pause");
	
}

int main()
{
	MainLandingPage();
	system("cls");
	cout<<"\n\n\t\t\t*******************************************************************"<<endl;
	cout<<"\t\t\t*******************************************************************"<<endl;

	cout << "\n\n\t\t\t\t\t RESTAURANT MANAGEMENT SYSTEM" << endl;
	int choice;
	cout << "\n\t\t\t1. Manage Customers" << endl;
	cout << "\n\t\t\t2. Manage Products" << endl;
	cout << "\n\t\t\tEnter Choice: ";
	cin >> choice;
	

	switch (choice) {
	case 1:
	{
		int choice;
		CustomerTree* customer = new CustomerTree();
		FoodItemsList* F = new FoodItemsList();

		do {
			system("cls");
			cout << "\n\n\t\t--------------------------------- Manage Customers ---------------------------------" << endl;
			cout << "\t\t1. Add Customer" << endl;
			cout << "\t\t2. Show Customer Records" << endl;
			cout << "\t\t3. Delete Customer Record" << endl;
			cout << "\t\t4. Update Customer Record" << endl;
			cout << "\t\t5. Search Customer Record" << endl;
			cout << "\t\t6. To Go Back Enter -1" << endl;
			cout << "\n\n\t\tEnter your Choice: ";
			cin >> choice;

			switch (choice) {
			case 1:
			{

				system("cls");
				cout << "\n\t\t--------------------------------- ADD CUSTOMER ---------------------------------\n\n";
				int customerID;
				string newCustomerName;
				double customerTotal;

				cout << "Enter Customer ID: ";
				cin >> customerID;
				
				if(customer->Search(customer->root, customerID)) {
					cout << "Cannot Insert. Customer ID already there...\n";
					break;
					system("pause");
				}

					cout << "Enter Customer Name: ";
					cin >> newCustomerName;

					if (newCustomerName == "") {
						cout << "Enter a valid name!!!";
						break;
						system("pause");
					}

					customerTotal = F->TakeOrder();

					ofstream file;
					file.open("CustomerData.txt", ios::app);
					if (!file) {
						cout << "\n\n\tError in opening File.";
					}
					file << "Customer ID: " << customerID << "\nCustomer Name: " << newCustomerName << "\nCustomer Total: " << customerTotal << endl << endl;
					file.close();
					
//					file << "Customer ID\t" << "Customer Name\t" << "Customer Total" << endl;
//					file << customerID << "\t\t" << newCustomerName << "\t\t" << customerTotal << endl;

					customer->root = customer->Insert(customer->root, customerID, newCustomerName, customerTotal);
					cout << "\nInsertion Successfully Performed" << endl;
				
				system("pause");
				break;
			}
			case 2:
			{
				system("cls");
//				Reading from File
				ifstream file("CustomerData.txt");
				if (!file) {
    			cout << "Error in opening file." << endl;
    			return 1;
				}
				string line;
				while (getline(file, line)) {
    				cout << line << endl;
				}
				file.close();
				
				//Reading from BST
//				if (customer->root != NULL) {
//					customer->InOrderDisplay(customer->root);
//				}
//				else {
//					cout << "No customer records found." << endl;
//				}
				system("pause");
				break;
			}
			case 3:
			{
				int delCustomer;
				system("cls");

				cout << "\nEnter Customer ID to Delete Customer Data: ";
				cin >> delCustomer;

				if (customer->Search(customer->root, delCustomer))
				{
					customer->root = customer->Delete(customer->root, delCustomer);
					cout << "\nCustomer Data Deleted Successfully" << endl;
				}
				else {
					cout << "No Matching Customer ID Found!!!" << endl;
				}

				system("pause");
				break;
			}
			case 5:
			{
				system("cls");
				int searchCusID;

				cout << "\nEnter Customer ID to Search Data: ";
				cin >> searchCusID;

				CustomerNode* searchCustomer = customer->Search(customer->root, searchCusID);

				if (searchCustomer != NULL) {
					cout << "Customer with Customer ID: " << searchCusID << " Exists in the Record" << endl;
					cout << "\nCustomer Name: " << searchCustomer->GetCustomerName() << endl;
					cout << "Customer Total: " << searchCustomer->GetCustomerTotal() << endl;
				}
				else {
					cout << "No Matching Customer ID Found!!!" << endl;
				}
				cout << "\n\n\n";
				system("pause");
			}
			case -1:
			{
				system("cls");
//				HomePage();
				cout << "Exiting!!!" << endl;
				break;
			}
			default:
				cout << "Wrong Input!!!" << endl;
				break;
			}
		} while (choice != -1);
		system("pause");
		break;
	}
	case 2:
	{
		FoodItemsList* F = new FoodItemsList();
		F->FoodItemsMenu();
		system("pause");
		break;
	}
	default:
		{
		cout << "Wrong Choice!!!";
		break;
		}
}

}

