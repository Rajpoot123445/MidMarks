#include <iostream>
#include <iomanip>
#include <limits>
#include <fstream>
#include "fooditem.h"
using namespace std;

class FoodItemsList {
	private:
		FoodItem* head;
	public: 
		FoodItemsList() {
			head = NULL;
		}
		void AddItem(int itemID, string itemName, double itemPrice) {
			FoodItem* newItem = new FoodItem(itemID, itemName, itemPrice);
			if (head == NULL) {
				head = newItem;
			}
			else {
				FoodItem* temp = head;
				while (temp->GetNext() != NULL) {
					temp = temp->GetNext();
				}
				temp->SetNext(newItem);
			}
		}
		
		FoodItem* FindItem(int itemID) {
			FoodItem* temp = head;
			while (temp != NULL) {
				if (temp->GetItemID() == itemID) {
					return temp;
				}
				temp = temp->GetNext();
			}
			return NULL;
		}
		
	
	void DeleteItem(int itemID) {
		if (head == NULL) {
			cout << "List is empty!" << endl;
			return;
		}

		FoodItem* temp = head;
		FoodItem* prev = NULL;

		if (temp != NULL && temp->GetItemID() == itemID) {
			head = temp->GetNext();
			delete temp;
			cout << "Item deleted successfully!" << endl;
			return;
		}

		while (temp != NULL && temp->GetItemID() != itemID) {
			prev = temp;
			temp = temp->GetNext();
		}

		if (temp == NULL) {
			cout << "Item not found!" << endl;
			return;
		}

		prev->SetNext(temp->GetNext());
		delete temp;
		cout << "Item deleted successfully!" << endl;
	}
	
	void UpdateItem(int itemID, string newItemName, double newItemPrice) {
		FoodItem* itemToUpdate = FindItem(itemID);
		if (itemToUpdate != NULL) {
			itemToUpdate->SetItemName(newItemName);
			itemToUpdate->SetItemPrice(newItemPrice);
			cout << "Item updated successfully!" << endl;
		}
		else {
			cout << "Item not found!" << endl;
		}
	}
	void DisplayItems() {
			FoodItem* temp = head;
			while (temp != NULL) {
				temp->ShowItem();
				temp = temp->GetNext();
			}
		}
		
	double TakeOrder() {
		
		FoodItemsList myList;
		myList.AddItem(1, "Pizza", 1200);
		myList.AddItem(2, "Burger", 500);
		myList.AddItem(3, "Pasta", 700);
		
	    cout << "\nHere are the available food items:" << endl;
	    
	    myList.DisplayItems();
	
	    int selectedItemID;
	    int quantity;
	
	    double totalBill = 0.0;
	
	    while (true) {
	        cout << "Enter the item ID you want to order (0 to exit): ";
	        cin >> selectedItemID;
	
	        if (selectedItemID == 0) {
	            break;
	        }
	
	        FoodItem* selectedItem = myList.FindItem(selectedItemID);
	
	        if (selectedItem == NULL) {
	            cout << "Invalid item ID. Please try again." << endl;
	            continue;
	        }
	
	        cout << "Enter the quantity: ";
	        cin >> quantity;
	
	        if (quantity <= 0) {
	            cout << "Invalid quantity. Please try again." << endl;
	            continue;
	        }
	
	        double itemPrice = selectedItem->GetItemPrice();
	        double itemTotal = itemPrice * quantity;
	        totalBill += itemTotal;
	
	        cout << "Added " << quantity << " " << selectedItem->GetItemName() << "(s) to the order." << endl;
	        cout << "Item total: PKR" << fixed << setprecision(2) << itemTotal << endl;
	        cout << endl;
	    }
		return totalBill;
	}
	
	
	void FoodItemsMenu() {
    int choice;
    FoodItemsList foodItems;

    do {
        system("cls");
        cout << "\n\n\t\t--------------------------------- Manage Food Items ---------------------------------" << endl;
        cout << "\t\t1. Add New Food Item" << endl;
        cout << "\t\t2. Show Food Items" << endl;
        cout << "\t\t3. Delete Food Item" << endl;
        cout << "\t\t4. Update Food Item" << endl;
        cout << "\t\t5. Search Item" << endl;
        cout << "\t\t6. To Go Back Enter -1" << endl;
        cout << "\n\n\t\tEnter your Choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                {
                    system("cls");
                    cout << "\n\t\t--------------------------------- ADD ITEM ---------------------------------\n\n";
                    int itemID;
                    string itemName;
                    double itemPrice;

                    cout << "Enter Food Item ID: ";
                    cin >> itemID;
					
					if(foodItems.FindItem(itemID))
					 {
					 	cout << "Item ID already exists!!!" << endl;
					 }
					 else {
					 
                    cout << "Enter Food Item Name: ";
                    cin >> itemName;

                    if (itemName.empty()) {
                        break;
                    }

                    cout <<"Enter Item Price: ";
                    cin >> itemPrice;
                    
                    ofstream file;
					file.open("FoodItems.txt",ios::app);
					if(!file){
						cout<<"\n\n\tError in opening File.";
					}
				file << "Item ID: " << itemID << "\nItem Name: " << itemName << "\nItem Price: " << itemPrice << endl << endl;
						file.close();
					

                    foodItems.AddItem(itemID, itemName, itemPrice);

                    cout << "\nInsertion Successfully Performed" << endl;
                    }
                    system("pause");
                    break;
                }
            case 2:
                {
                    system("cls");
				ifstream file("FoodItems.txt");
				if (!file) {
    			cout << "Error in opening file." << endl;
//    			return 1;
				}
				string line;
				while (getline(file, line)) {
    				cout << line << endl;
				}
				file.close();
//                    if (foodItems == NULL) 
//                    {
//                    	cout << "No food records found." << endl;
//					}           
//                    else {
//                        foodItems.DisplayItems();  
//            	   }
                    system("pause");
                    break;
                }
            case 3:
                {
                    int delItem;
                    system("cls");

                    cout << "\nEnter Item ID to Delete Item Data: ";
                    cin >> delItem;

                    if(foodItems.FindItem(delItem))
                    {
                        foodItems.DeleteItem(delItem);
                        cout << "\nItem Data Deleted Successfully" << endl;
                    }
                    else {
                        cout << "No Matching Item ID Found!!!" << endl;
                    }

                    system("pause");
                    break;
                }
            case 4:
                {
                    system("cls");
                    cout << "\n\t\t--------------------------------- UPDATE ITEM ---------------------------------\n\n";
                    int updateItemID;
                    string updateItemName;
                    double updateItemPrice;

                    cout << "Enter Item ID to update: ";
                    cin >> updateItemID;

                    FoodItem* updateItem = foodItems.FindItem(updateItemID);

                    if (updateItem != NULL) {
                        cout << "Enter updated Item Name: ";
                        cin >> updateItemName;

                        cout << "Enter updated Item Price: ";
                        cin >> updateItemPrice;

                        // Update the item record
                        foodItems.UpdateItem(updateItemID, updateItemName, updateItemPrice);

                        cout << "\nUpdate Successfully Performed" << endl;
                    }
                    else {
                        cout << "Item ID not found!" << endl;
                    }

                    system("pause");
                    break;
                }
            case 5:
                {
                    system("cls");
                    int searchItemID;

                    cout << "\nEnter Item ID to Search Data: ";
                    cin >> searchItemID;

                    FoodItem* searchItem = foodItems.FindItem(searchItemID);

                    if(searchItem != NULL) {
                        cout << "Item with Item ID: " << searchItemID << " Exists in the Record" << endl;
                        cout << "Item Name: " << searchItem->GetItemName() << endl;
                        cout << "Item Price: " << searchItem->GetItemPrice() << endl;
                    }
                    else {
                        cout << "No Matching Item ID Found!!!" << endl;
                    }
                    cout << "\n\n\n";
                    system("pause");
                    break;
                }
            case -1:
                {
                    system("cls");
                    cout << "Moving Back !!!" << endl;
                    break;
                }
            default:
                cout << "Wrong Input!!!" << endl;
                break;
        }

    } while (choice != -1);
}

};
