#include <iostream>
using namespace std;


class FoodItem {
	private:
		int itemID;
		string itemName;
		double itemPrice;
		FoodItem* next;
		
	public:
		FoodItem() {
			itemID = 0;
			itemName = "";
			itemPrice = 0.0;
			next = NULL;
		}
		FoodItem(int itemID, string itemName, double itemPrice) {
			this->itemID = itemID;
			this->itemName= itemName;
			this->itemPrice = itemPrice;
			this->next = NULL;
		}
		
		void SetItemID(int itemID) {
			this->itemID = itemID;
		}
		void SetItemName(string itemName) {
			this->itemName = itemName;
		}
		void SetItemPrice(double itemPrice) {
			this->itemPrice = itemPrice;
		}
		void SetNext(FoodItem* next) {
			this->next = next;
		}
		FoodItem* GetNext() {
			return next;
		}
		int GetItemID() {
        	return itemID;
    		}

    	double GetItemPrice() {
        	return itemPrice;
    		}
    		
    	string GetItemName() {
    		return itemName;
			}
		void ShowItem() {
        	cout << "Item ID: " << itemID << " , Item Name: " << itemName << " , Item Price: " << itemPrice << endl;
        	cout << endl;
  			}
};

