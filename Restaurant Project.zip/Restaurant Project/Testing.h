#include <iostream>
#include <iomanip>
#include <limits>
#include <fstream>
//#include "fooditems.h"

using namespace std;

class CustomerNode {
private:
    int customerID;
    CustomerNode* left;
    CustomerNode* right;
    string customerName;
    double customerTotal;

public:
    CustomerNode() {
        this->customerID = 0;
        this->customerName = "default";
        this->customerTotal = 0.0;
        left = NULL;
        right = NULL;
    }

    CustomerNode(int customerID, string customerName, double customerTotal) {
        this->customerID = customerID;
        this->customerName = customerName;
        this->customerTotal = customerTotal;
        left = NULL;
        right = NULL;
    }

    void SetCustomerID(int customerID) {
        this->customerID = customerID;
    }

    int GetCustomerID() {
        return customerID;
    }

    void SetCustomerName(string customerName) {
        this->customerName = customerName;
    }

    string GetCustomerName() {
        return customerName;
    }

    void SetCustomerTotal(double customerTotal) {
        this->customerTotal = customerTotal;
    }

    double GetCustomerTotal() {
        return customerTotal;
    }

    CustomerNode* GetLeft() {
        return left;
    }

    void SetLeft(CustomerNode* left) {
        this->left = left;
    }

    CustomerNode* GetRight() {
        return right;
    }

    void SetRight(CustomerNode* right) {
        this->right = right;
    }
};

class CustomerTree {
	
	public: 
		CustomerNode* root;
	
//	Inserting in the Customer BST 
    CustomerNode* Insert(CustomerNode* root, int customerID, string customerName, double customerTotal) {
    	CustomerNode* temp = new CustomerNode(customerID, customerName, customerTotal);

    if (root == NULL) {
        root = temp;
    }
    else {
        CustomerNode* current = root;
        bool inserted = false;
        while (!inserted) {
            if (customerID < current->GetCustomerID()) {
                if (current->GetLeft() == NULL) {
                    current->SetLeft(temp);
                    inserted = true;
                }
                else {
                    current = current->GetLeft();
                }
            }
            else if (customerID > current->GetCustomerID()) {
                if (current->GetRight() == NULL) {
                    current->SetRight(temp);
                    inserted = true;
                }
                else {
                    current = current->GetRight();
                }
            }
        }
    }

    return root; // Return the new root after insertion
}

void InOrderDisplay(CustomerNode* root) {
        if (root != NULL) {
            InOrderDisplay(root->GetLeft());
            cout << "\nCustomer ID: " << root->GetCustomerID() << endl;
            cout << "Customer Name: " << root->GetCustomerName() << endl;
            cout << "Customer Total: " << root->GetCustomerTotal() << endl << endl;
            InOrderDisplay(root->GetRight());
        }
    }
    
	int MinValue(CustomerNode* root) {
        int min = root->GetCustomerID();
        while (root->GetLeft() != NULL) {
            min = root->GetLeft()->GetCustomerID();
            root = root->GetLeft();
        }
        return min;
    }
    
	CustomerNode* Search(CustomerNode* root, int customerID) {
        if (root == NULL || root->GetCustomerID() == customerID) {
            return root;
        }
        if (customerID < root->GetCustomerID()) {
            return Search(root->GetLeft(), customerID);
        }
        return Search(root->GetRight(), customerID);
    }

CustomerNode* Delete(CustomerNode* root, int customerID) {
        if (root == NULL) {
            cout << "Customer ID not found!!!" << endl;
            return root;
        }
        if (customerID < root->GetCustomerID()) {
            root->SetLeft(Delete(root->GetLeft(), customerID));
        }
        else if (customerID > root->GetCustomerID()) {
            root->SetRight(Delete(root->GetRight(), customerID));
        }
        else {
            if (root->GetLeft() == NULL && root->GetRight() == NULL) {
                delete root;
                root = NULL;
            }
            else if (root->GetLeft() == NULL) {
                CustomerNode* temp = root;
                root = root->GetRight();
                delete temp;
            }
            else if (root->GetRight() == NULL) {
                CustomerNode* temp = root;
                root = root->GetLeft();
                delete temp;
            }
            else {
                int min = MinValue(root->GetRight());
                root->SetCustomerID(min);
                root->SetRight(Delete(root->GetRight(), min));
            }
        }
        return root;
    }
    void Update(CustomerNode* root, int customerID, string newCustomerName, double newCustomerTotal) {
    if (root == NULL) {
        cout << "Customer ID not found!" << endl;
        return;
    }

    if (customerID < root->GetCustomerID()) {
        Update(root->GetLeft(), customerID, newCustomerName, newCustomerTotal);
    }
    else if (customerID > root->GetCustomerID()) {
        Update(root->GetRight(), customerID, newCustomerName, newCustomerTotal);
    }
    else {
        // Customer ID matches, update the fields
        root->SetCustomerName(newCustomerName);
        root->SetCustomerTotal(newCustomerTotal);
        cout << "Customer information updated successfully!" << endl;
    }
}
};
//void HomePage() {
//	system("cls");
//	
//	cout<<"\n\n\t\t\t*******************************************************************"<<endl;
//	cout<<"\t\t\t*******************************************************************"<<endl;
//	
//		cout << "\n\n\t\t\t\t\t RESTAURANT MANAGEMENT SYSTEM" << endl;
//		int choice;
//		cout << "\n\t\t\t1. Manage Products" << endl;
//		cout << "\n\t\t\t2. Manage Customers" << endl;
//		cout << "\n\t\t\tEnter Choice: ";
//		cin >> choice;
//		
//	
//		switch(choice) {
//			case 1:	
//			{
//				FoodItemsList* F = new FoodItemsList();
//				F->FoodItemsMenu();
//				system("pause");
//				break;
//			}
//			case 2:
//			{
//	   			CustomerTree* root;
//				root->AddCustomerMenu();
//				system("pause");
//				break;
//			}
//			default:
//				cout << "Wrong Choice!!!";
//				break;
//		}
//	
//}
//};

//int main() {
//	
//		FoodItemsList* myList = new FoodItemsList();
//	    myList->AddItem(1, "Pizza", 9.99);
//	    myList->AddItem(2, "Burger", 5.99);
//	    myList->AddItem(3, "Salad", 7.49);
//
////		CustomerTree* C = new CustomerTree();
////		C->LandingPage();
////		C->HomePage();
//	
//	
//	
//    return 0;
//}

