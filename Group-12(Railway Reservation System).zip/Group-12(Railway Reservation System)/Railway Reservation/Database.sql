CREATE DATABASE RailwaySystem;
Drop Database RailwaySystem;
use RailwaySystem;

----------Creating Tables--------
CREATE TABLE TrainMaster
	(TId	INTEGER	NOT NULL PRIMARY KEY	IDENTITY(300, 1),
	 TName	VARCHAR(50) NOT NULL,
	 TCap	INTEGER NOT NULL,
	 TStatus VARCHAR(30) NOT NULL);

CREATE TABLE PassengerMaster
	(PId	INTEGER	NOT NULL	PRIMARY KEY	IDENTITY(100, 1),
	 PName	VARCHAR(50) NOT NULL,
	 PAdress VARCHAR(50) NOT NULL,
	 PGender VARCHAR(10) NOT NULL,
	 PCity	VARCHAR(50) NOT NULL,
	 Phone	VARCHAR(12) NOT NULL);

CREATE TABLE Cancel_T
	(CancId	INT	NOT NULL PRIMARY KEY	IDENTITY(500, 1),
	 TickID INT NOT NULL,
	 CancDate	DATE	NOT NULL);

CREATE TABLE Travel_T
	(TravCode	INT	NOT NULL	PRIMARY KEY	IDENTITY(1000, 1),
	 TravDate	Date	NOT NULL,
	 TCode		INT	NOT NULL,
	 TSource	VARCHAR(50)	NOT NULL,
	 TDestin	VARCHAR(50)	NOT NULL,
	 TCost		INT	NOT NULL);

CREATE TABLE Reservation_T
	(TicketID	INT	NOT NULL	PRIMARY KEY	IDENTITY(2000,1),
	 PId		INT	NOT NULL,
	 PName		VARCHAR(50)	NOT NULL,
	 TravCode	INT NOT NULL,
	 TravDate	Date	NOT NULL,
	 TravSrc	VARCHAR(50)	NOT NULL,
	 TravDest	VARCHAR(50)	NOT NULL,
	 TravCost	INT	NOT NULL);

----------Showing all Tables-------
SELECT * FROM TrainMaster;
SELECT * FROM PassengerMaster;
SELECT * FROM Travel_T;
SELECT * FROM Reservation_T;
SELECT * FROM Cancel_T;