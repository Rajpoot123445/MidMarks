﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Railway_Reservation
{
    public partial class ReservationMaster : Form
    {
        public ReservationMaster()
        {
            InitializeComponent();
            populate();
            fillpid();
            filltid();
            GetPName();
            GetTravel();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            MainForm back = new MainForm();
            back.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MainForm go = new MainForm();
            go.Show();
            this.Hide();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VP4PJHB;Initial Catalog=RailwaySystem;Integrated Security=True");

        private void populate()
        {
            con.Open();
            string Query = "SELECT * FROM Reservation_T";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            var ds = new DataSet();
            sda.Fill(ds);
            ReservationData.DataSource = ds.Tables[0];
            con.Close();
        }
        private void fillpid()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT PId FROM PassengerMaster", con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("PId", typeof(int));
            dt.Load(rdr);
            cmbPassenger.ValueMember = "PId";
            cmbPassenger.DataSource = dt;
            con.Close();
        }

        private void filltid()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT TravCode FROM Travel_T", con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("TravCode", typeof(int));
            dt.Load(rdr);
            cmbTravel.ValueMember = "TravCode";
            cmbTravel.DataSource = dt;
            con.Close();
        }
        string pname;
        private void GetPName()
        {
            con.Open();
            string rrr = "SELECT * FROM PassengerMaster Where PId = " + cmbPassenger.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(rrr, con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach(DataRow dr in dt.Rows)
            {
                pname = dr["PName"].ToString();
            }
            con.Close();
        }
        string Date, Src, Desti;
        int Cost;
        private void GetTravel()
        {
            con.Open();
            string rrr = "SELECT * FROM Travel_T Where TravCode = " + cmbTravel.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(rrr, con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                Date = dr["TravDate"].ToString();
                Src = dr["TSource"].ToString();
                Desti = dr["TDestin"].ToString();
                Cost = Convert.ToInt32(dr["TCost"].ToString());
            }
            con.Close();
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cmbPassenger.SelectedIndex == -1 || cmbTravel.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information!!!!!");
            }
            else
            {
                try
                {
                    con.Open();
                    string Query = "INSERT INTO Reservation_T VALUES(" + cmbPassenger.SelectedValue.ToString() + ",'"+pname+"','" + cmbTravel.SelectedValue.ToString() + "','" + Date + "','" + Src + "','"+Desti+"',"+Cost+")";
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
    }
}
