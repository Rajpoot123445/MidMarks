﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Railway_Reservation
{
    public partial class TrainMaster : Form
    {
        public TrainMaster()
        {
            InitializeComponent();
            populate();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void TarinMaster_Load(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MainForm go = new MainForm();
            go.Show();
            this.Hide();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VP4PJHB;Initial Catalog=RailwaySystem;Integrated Security=True");
        private void populate()
        {
            con.Open();
            string Query = "SELECT * FROM TrainMaster";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            var ds = new DataSet();
            sda.Fill(ds);
            dataView.DataSource = ds.Tables[0];
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string TrStatus = "";
            if (trainName.Text == "" || txtCapacity.Text == "")
            {
                MessageBox.Show("Missing Information!!!!!");
            }
            else
            {
                if (btnBusy.Checked == true)
                {
                    TrStatus = "Busy";
                }
                else if (btnAvailalble.Checked == true)
                {
                    TrStatus = "Available";
                }
                try
                {
                    con.Open();
                    string Query = "INSERT INTO TrainMaster VALUES('" + trainName.Text + "'," + txtCapacity.Text + ",'" + TrStatus + "')";
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
    
        private void btnReset_Click(object sender, EventArgs e)
        {
            trainName.Text = "";
            txtCapacity.Text = "";
            btnBusy.Checked = false;
            btnAvailalble.Checked = false;
        }
        //private void dataView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //{
            
        //    trainName.Text = dataView.SelectedRows[0].Cells[1].Value.ToString();
        //    txtCapacity.Text = dataView.SelectedRows[0].Cells[2].Value.ToString();
        //    if(trainName.Text == "")
        //    {
        //        key = 0;
        //    }
        //    else
        //    {
        //        key = Convert.ToInt32(dataView.SelectedRows[0].Cells[0].Value.ToString());
        //    }
        
        //}

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //if(key == 0)
            //{
            //    MessageBox.Show("Select the train to be deleted!!!!!");
            //}
            //else
            //{
            //    try
            //    {
            //        con.Open();
            //        string Query = "DELETE FROM TrainMaster WHERE TId = "+key+"";
            //        SqlCommand cmd = new SqlCommand(Query, con);
            //        cmd.ExecuteNonQuery();
            //        MessageBox.Show("Train be deleted Successfully.......");
            //        con.Close();
            //        populate();
            //    }
            //    catch (Exception Ex)
            //    {
            //        MessageBox.Show(Ex.Message);
            //    }
            //}
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Delete From TrainMaster Where TName = '" + trainName.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            populate();
           //MessageBox.Show("Record Delete Successfully......");
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            string TrStatus = "";
            if (trainName.Text == "" || txtCapacity.Text == "")
            {
                MessageBox.Show("Missing Information!!!!!");
            }
            else
            {
                if (btnBusy.Checked == true)
                {
                    TrStatus = "Busy";
                }
                else if (btnAvailalble.Checked == true)
                {
                    TrStatus = "Available";
                }
                try
                {
                    con.Open();
                    string Query = "update TrainMaster set TCap = '"+txtCapacity.Text+"',TStatus = '"+TrStatus+"' Where TName = '"+trainName.Text+"'";
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Train Update Successfully!!!!!");
                    con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void reset()
        {
            trainName.Text = "";
            txtCapacity.Text = "";
            btnBusy.Checked = false;
            btnAvailalble.Checked = false;
        }
        private void btnReset_Click_1(object sender, EventArgs e)
        {
            reset();
        }
    }
}
