﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Railway_Reservation
{
    public partial class PassengerMaster : Form
    {
        public PassengerMaster()
        {
            InitializeComponent();
            populate();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            MainForm home = new MainForm();
            home.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MainForm go = new MainForm();
            go.Show();
            this.Hide();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VP4PJHB;Initial Catalog=RailwaySystem;Integrated Security=True");

        private void populate()
        {
            con.Open();
            string Query = "SELECT * FROM PassengerMaster";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            var ds = new DataSet();
            sda.Fill(ds);
            DataviewGrid.DataSource = ds.Tables[0];
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string Gender = "";
            if (txtName.Text == "" || txtAddress.Text == "" || txtPhone.Text == "")
            {
                MessageBox.Show("Missing Information!!!!!");
            }
            else
            {
                if (btnMale.Checked == true)
                {
                    Gender = "Male";
                }
                else if (btnFemale.Checked == true)
                {
                    Gender = "Female";
                }
                try
                {
                    con.Open();
                    string Query = "INSERT INTO PassengerMaster VALUES('" + txtName.Text + "','" + txtAddress.Text + "','" + Gender + "','" + cmbcitizen.SelectedItem.ToString() + "','" + txtPhone.Text + "')";
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtAddress.Text = "";
            btnMale.Checked = false;
            btnFemale.Checked = false;
            cmbcitizen.SelectedItem = "";
            txtPhone.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Delete From PassengerMaster Where PName = '" + txtName.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Delete Successfully!!!!!!");
            populate();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            string Gender = "";
            if (txtName.Text == "" || txtAddress.Text == "" || txtPhone.Text == "")
            {
                MessageBox.Show("Missing Information!!!!!");
            }
            else
            {
                if (btnMale.Checked == true)
                {
                    Gender = "Male";
                }
                else if (btnFemale.Checked == true)
                {
                    Gender = "Female";
                }
                try
                {
                    con.Open();
                    string Query = "Update PassengerMaster Set PAdress='" + txtAddress.Text + "',PGender='" +Gender+ "',PCity='" +cmbcitizen.SelectedItem.ToString()+ "',Phone='" +txtPhone.Text+ "' WHERE PName='"+txtName.Text+"'";
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record Update Successfully!!!!!!");
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
    }
}
