﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Railway_Reservation
{
    public partial class TravelMaster : Form
    {
        public TravelMaster()
        {
            InitializeComponent();
            populate();
            fillTCode();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            MainForm home = new MainForm();
            home.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MainForm go = new MainForm();
            go.Show();
            this.Hide();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VP4PJHB;Initial Catalog=RailwaySystem;Integrated Security=True");

        private void populate()
        {
            con.Open();
            string Query = "SELECT * FROM Travel_T";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            var ds = new DataSet();
            sda.Fill(ds);
            TravelData.DataSource = ds.Tables[0];
            con.Close();
        }
        private void fillTCode()
        {
            string TrStatus = "Available";
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT TId FROM TrainMaster WHERE TStatus='"+TrStatus+"'", con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("TId", typeof(int));
            dt.Load(rdr);
            cmbCode.ValueMember = "TId";
            cmbCode.DataSource = dt;
            con.Close();
        }
        private void changeoccur()
        {
            string TrStatus = "Busy";
            try
                {
                    con.Open();
                    string Query = "update TrainMaster set TStatus = '" + TrStatus + "' Where TId = '" + cmbCode.SelectedValue.ToString() + "';";
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.ExecuteNonQuery();
                    //MessageBox.Show("Train Update Successfully!!!!!");
                    con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
        }
        //public void TravelView()
        //{
        //    string TrStatus = "Busy";
        //    try
        //        {
        //            con.Open();
        //            string Query = "update TrainMaster set TStatus = '" + TrStatus + "' Where TId = '" + cmbCode.SelectedValue.ToString() + "';";
        //            SqlCommand cmd = new SqlCommand(Query, con);
        //            cmd.ExecuteNonQuery();
        //            //MessageBox.Show("Train Update Successfully!!!!!");
        //            con.Close();
        //            populate();
        //        }
        //        catch (Exception Ex)
        //        {
        //            MessageBox.Show(Ex.Message);
        //        }
        //}
        private void button1_Click(object sender, EventArgs e)
        {
            if (txtCost.Text == "" || cmbCode.SelectedIndex == -1 || cmbSource.SelectedIndex == -1 || cmbDestination.SelectedIndex == -1 )
            {
                MessageBox.Show("Missing Information!!!!!");
            }
            else
            {
                try
                {
                    con.Open();
                    string Query = "INSERT INTO Travel_T VALUES('" + TravDate.Value + "','" + cmbCode.SelectedValue.ToString() + "','" + cmbSource.SelectedItem.ToString() + "','" + cmbDestination.SelectedItem.ToString() + "','" + txtCost.Text + "')";
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    populate();
                    changeoccur();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            cmbSource.SelectedIndex = -1;
            cmbDestination.SelectedIndex = -1;
            cmbCode.SelectedIndex = -1;
            txtCost.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)     // Update by using cost
        {
            if (cmbSource.SelectedIndex == -1 || cmbDestination.SelectedIndex == -1 || txtCost.Text == "")
            {
                MessageBox.Show("Missing Information!!!!!");
            }
            else
            {
               try
                {
                    con.Open();
                    string Query = "update Travel_T set TravDate = '" + TravDate.Text + "',TCode = '" + cmbCode.SelectedValue.ToString() + "',TSource = '" + cmbSource.SelectedItem.ToString() + "',TDestin = '" + cmbDestination.SelectedItem.ToString() + "' Where TCost = '" + txtCost.Text + "'";
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Travel Update Successfully!!!!!");
                    con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void TravelData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
